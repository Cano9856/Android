package com.example.singleton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.singleton.data.GlovoData;
import com.example.singleton.services.ServicePantallaPrincipal;

public class MainActivity extends AppCompatActivity {
    private Button btnSaludar;
    private Button btnInicioSesion;
    private TextView email;
    private TextView password;
    // onLoad: Javascript  == onCreate: Java //

    /////// PATRÓN SINGLETON
    private static MainActivity padre;
    public static MainActivity getInstance(){
        return padre;
    }
    // FIN PATRÓN SINGLETON

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        email= findViewById(R.id.emailInput);
        password= findViewById(R.id.passwdInput);
        btnInicioSesion = findViewById(R.id.btnInicioSesion);

        //Singleton
        this.padre= this;
        //Fin singleton

        ServicePantallaPrincipal service = new ServicePantallaPrincipal();
        //ServicePantallaPrincipal service1 = new ServicePantallaPrincipal();

        btnSaludar=findViewById(R.id.btnSaludar01);
        btnSaludar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                service.saludar();
            }
        });

        if (GlovoData.getEmail()!=null&&GlovoData.getEmail().length()>0) {
            String email= GlovoData.getEmail();
            Toast.makeText(getBaseContext(), "Gracias "+ email, Toast.LENGTH_SHORT).show();
        }

        btnInicioSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                spPrincipal.altaUsuario();
                String emailInsertado = email.getText().toString();
                String passInsertada = password.getText().toString();
                service.inicioSesion(emailInsertado, passInsertada);


                //GlovoData.setEmail(txtEmail.getText().toString());
                //getBaseContext sería igual a MainActivity2.getInstance() en este caso

            }
        });

        //INVESTIGAR INTENT (OBJETIVO: NAVEGAR DE UNA PANTALLA A OTRA)
            //TECNICAMENTE SON SOLO DOS LINEAS DE CÓDIGO

    }
}