package com.example.singleton.services;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.singleton.MainActivity;
import com.example.singleton.MainActivity2;
import com.example.singleton.data.GlovoData;
import com.example.singleton.listeners.MyListener;

public class ServicePantallaPrincipal {

    private MyListener myListener;

    public void setMyListener(MyListener myListener){
        this.myListener= myListener;
    }

    public void simularAccionDeListener(){
        if (myListener!=null){
            myListener.onSaludar();
        }
    }

    public ServicePantallaPrincipal() {

    }

    public void saludar(){
        Toast.makeText(MainActivity.getInstance(),
                "Saludar a Android",
                Toast.LENGTH_SHORT).show();
                                                        //ORIGEN                //DESTINO
        Intent navegarEntrePantallas= new Intent(MainActivity.getInstance(), MainActivity2.class);
        MainActivity.getInstance().startActivity(navegarEntrePantallas);
    }
    public void altaUsuario(){
        Toast.makeText(MainActivity2.getInstance(), "Hola segunda pantalla!!!", Toast.LENGTH_SHORT).show();
    }

    public void inicioSesion(String email, String pass){


        GlovoData.setEmail(email);
        GlovoData.setPassword(pass);

        Toast.makeText(MainActivity.getInstance(), "Bienvenido "+ email+ ". Su contraseña es "+ pass, Toast.LENGTH_SHORT).show();


    }


    public void textoToast(String texto){
        Toast.makeText(MainActivity.getInstance(), texto, Toast.LENGTH_SHORT).show();
    }
//    public void Actionsaludar(Context context){
//        Toast.makeText(context,
//                "Saludar a Android",
//                Toast.LENGTH_SHORT).show();
//    }


}
