package com.example.singleton.listeners;

public interface MyListener {

   void onSaludar();


}
