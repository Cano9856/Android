package com.example.singleton.data;

public class GlovoData {
    private static String email;
    private static String password;


    //private static User user

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        GlovoData.email = email;
    }


    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        GlovoData.password = password;
    }
}
